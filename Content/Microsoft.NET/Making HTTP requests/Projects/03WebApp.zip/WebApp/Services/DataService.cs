using System.Net.Http.Json;

namespace WebApp.Services;

public interface IDataService {
    Task<T> GetData<T>(string url);
}

public class DataService : IDataService {
    private readonly HttpClient _client;

    public DataService(HttpClient client) {
        _client = client;
    }

    public async Task<T> GetData<T>(string url) {
        return await _client.GetFromJsonAsync<T>(url);
    }
}