class Singleton1 {
    private static _shared: Singleton1

    static get shared(): Singleton1 {
        if (!this._shared) {
            this._shared = new this()
        }
        return this._shared
    }

    names = ["Arya", "Sansa", "Robb", "Bran"]

    protected constructor() {}
}

const singleton2 = {
    names: ["Arya", "Sansa", "Robb", "Bran"]
}

console.log(Singleton1.shared.names)
console.log(singleton2.names)