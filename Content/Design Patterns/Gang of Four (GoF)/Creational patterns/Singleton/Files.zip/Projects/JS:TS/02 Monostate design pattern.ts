class CompanyCEO {
    private static _name = "John Doe";
    private static _age = 0;
    
    get name(): string {
        return CompanyCEO._name;
    }

    set name(value: string) {
        CompanyCEO._name = value
    }
    
    get age(): number {
        return CompanyCEO._age
    }

    set age(value: number) {
        CompanyCEO._age = value;
    }
}

// Multiple instances
const instance1 = new CompanyCEO()
const instance2 = new CompanyCEO()
const instance3 = new CompanyCEO()

instance1.name = 'John Doe'

console.log(instance1.name)
console.log(instance2.name)
console.log(instance3.name)