import Foundation

enum ThisIsNotASingleton {
    static var names = ["Arya", "Sansa", "Robb", "Bran"]

    static func foo() {
        print("Hello, World!")
    }
}

final class Singleton {
    private(set) var names = ["Arya", "Sansa", "Robb", "Bran"]
    static let shared = Singleton()
    
    private init() {}
    
    func foo() {
        print("Hello, World!")
    }
}

// let instance = ThisIsNotASingleton() // ❌ Compile error
// let instance = Singleton() // ❌ Compile error, the constructor is private

ThisIsNotASingleton.names.forEach { name in
    print(name)
}

ThisIsNotASingleton.foo()

Singleton.shared.names.forEach { name in
    print(name)
}

Singleton.shared.foo()
