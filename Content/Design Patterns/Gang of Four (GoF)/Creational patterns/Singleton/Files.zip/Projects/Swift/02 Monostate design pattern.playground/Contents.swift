import Foundation

final class CompanyCEO {
    private static var _name = ""
    private static var _age = 0
    
    var name: String {
        get { Self._name }
        set { Self._name = newValue }
    }
    
    var age: Int {
        get { Self._age }
        set { Self._age = newValue }
    }
}

// Multiple instances
let instance1 = CompanyCEO()
let instance2 = CompanyCEO()
let instance3 = CompanyCEO()

instance1.name = "John Doe"

print(instance1.name)
print(instance2.name)
print(instance3.name)
