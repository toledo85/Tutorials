﻿Singleton.Shared.names.ForEach(Console.WriteLine);

public class Singleton {
    public List<string> names = ["Arya", "Sansa", "Robb", "Bran"];
    public static Singleton Shared => LazyInstance.Value;
    
    private static readonly Lazy<Singleton> LazyInstance = 
        new Lazy<Singleton>(() => {
            return new();
        });

    private Singleton() { }
}