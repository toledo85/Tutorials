class Singleton1 private constructor() {
    var names = arrayOf("Arya", "Bran", "Robb", "Sansa")
        private set

    companion object {
        val shared: Singleton by lazy {
            Singleton()
        }
    }
}

object Singleton2 {
    var names = mutableListOf("Arya", "Bran", "Robb", "Sansa")
        private set
}

fun main() {
    Singleton1.shared.names.forEach {
        println(it)
    }

    Singleton2.shared.names.forEach {
        println(it)
    }
}