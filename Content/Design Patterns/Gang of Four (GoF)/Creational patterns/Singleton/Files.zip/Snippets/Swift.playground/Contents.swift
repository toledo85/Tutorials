import Foundation

struct Patient {}

final class SessionManager {
    static let kCachedUserAuthToken = "authToken"
    static let kCachedAccountId = "accountId"
    static let kCachedActivePatient = "activePatient"
    
    var authToken: String?
    var accountId: Int?
    var activePatient: Patient?
    var predictedFVC: Double?
    
    static let shared = SessionManager()
    
    private init() {}
}

print(SessionManager.shared.authToken ?? "")
print(SessionManager.shared.accountId ?? "")
print(SessionManager.shared.predictedFVC ?? "")
print(SessionManager.shared.predictedFVC ?? "")

print(SessionManager.kCachedUserAuthToken)
print(SessionManager.kCachedAccountId)
print(SessionManager.kCachedActivePatient)
